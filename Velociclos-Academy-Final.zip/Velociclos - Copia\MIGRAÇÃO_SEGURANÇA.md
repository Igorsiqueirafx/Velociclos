# Guia de Migração para Versão Segura

## 🎯 Objetivo

Migrar o código existente para usar os novos utilitários de segurança, melhorando a proteção contra vulnerabilidades.

## 📋 Checklist de Migração

### Fase 1: Preparação

- [x] Utilitários de segurança criados
- [x] Utilitários de validação criados
- [x] Utilitários de performance criados
- [ ] Backup do código atual
- [ ] Testes do sistema atual funcionando

### Fase 2: Substituir innerHTML

#### Arquivo: `js/veloacademy.js`

**Antes:**
```javascript
quizView.innerHTML = `
    <div class="quiz-header">
        <h2>Quiz - ${courseTitle}</h2>
    </div>
`;
```

**Depois:**
```javascript
import { createSafeElement } from './utils/dom.js';

const header = createSafeElement('div', { class: 'quiz-header' });
const title = createSafeElement('h2', {}, `Quiz - ${courseTitle}`);
header.appendChild(title);
quizView.appendChild(header);
```

**Locais a atualizar:**
- Linha 260: `quizView.innerHTML = ...`
- Linha 529: `quizView.innerHTML = resultHTML;`
- Linha 668: `quizView.innerHTML = resultHTML;`
- Linha 1087: `coursesGrid.innerHTML = '';`
- Linha 1118: `card.innerHTML = ...`
- Linha 1663: `courseView.innerHTML = ...`
- Linha 1987: `contentModal.innerHTML = ...`
- Linha 2032: `bodyElement.innerHTML = decodedContent;`

### Fase 3: Adicionar Validação

#### Validação de IDs de Curso

**Antes:**
```javascript
openCourse(courseId) {
    const course = this.courseDatabase[courseId];
    // ...
}
```

**Depois:**
```javascript
import { sanitizeCourseId } from './utils/security.js';
import { Validator } from './utils/validation.js';

openCourse(courseId) {
    const sanitizedId = sanitizeCourseId(courseId);
    if (!sanitizedId) {
        console.error('ID de curso inválido');
        return;
    }
    
    const course = this.courseDatabase[sanitizedId];
    // ...
}
```

#### Validação de Respostas de Quiz

**Antes:**
```javascript
selectAnswer(answerIndex) {
    this.currentQuiz.userAnswers[this.currentQuiz.currentQuestion] = answerIndex;
}
```

**Depois:**
```javascript
import { Validator } from './utils/validation.js';

selectAnswer(answerIndex) {
    if (!Validator.validateQuizAnswer(answerIndex, 4)) {
        console.error('Resposta inválida');
        return;
    }
    this.currentQuiz.userAnswers[this.currentQuiz.currentQuestion] = answerIndex;
}
```

### Fase 4: Sanitizar Dados do Usuário

#### localStorage

**Antes:**
```javascript
localStorage.setItem('userName', payload.name);
localStorage.setItem('userEmail', payload.email);
```

**Depois:**
```javascript
import { sanitizeUserData } from './utils/security.js';

const sanitized = sanitizeUserData({
    name: payload.name,
    email: payload.email,
    picture: payload.picture
});

localStorage.setItem('userName', sanitized.name);
localStorage.setItem('userEmail', sanitized.email);
```

### Fase 5: Validar URLs

**Antes:**
```javascript
window.open(url, '_blank');
```

**Depois:**
```javascript
import { validateURL } from './utils/security.js';

if (validateURL(url)) {
    window.open(url, '_blank');
} else {
    console.error('URL inválida:', url);
}
```

### Fase 6: Adicionar Performance

#### Cache de Requisições

**Antes:**
```javascript
const response = await fetch('./cursos.json');
const data = await response.json();
```

**Depois:**
```javascript
import { SimpleCache, fetchWithCache } from './utils/performance.js';

const apiCache = new SimpleCache(50, 300000); // 5 minutos

const data = await fetchWithCache('./cursos.json', {}, apiCache);
```

#### Debounce em Event Listeners

**Antes:**
```javascript
searchInput.addEventListener('input', (e) => {
    performSearch(e.target.value);
});
```

**Depois:**
```javascript
import { debounce } from './utils/performance.js';

const debouncedSearch = debounce((query) => {
    performSearch(query);
}, 300);

searchInput.addEventListener('input', (e) => {
    debouncedSearch(e.target.value);
});
```

## 🔄 Ordem de Migração Recomendada

1. **Primeiro**: Substituir innerHTML críticos (quiz, cursos)
2. **Segundo**: Adicionar validação de entrada
3. **Terceiro**: Sanitizar dados do usuário
4. **Quarto**: Validar URLs
5. **Quinto**: Adicionar otimizações de performance
6. **Sexto**: Testar tudo

## ⚠️ Atenção

- **NÃO** migrar tudo de uma vez
- **SEMPRE** testar após cada mudança
- **MANTER** backup do código original
- **DOCUMENTAR** mudanças feitas

## 🧪 Testes Após Migração

1. Executar testes de segurança: `npm run test:security`
2. Executar testes de validação: `npm run test:validation`
3. Testar manualmente todas as funcionalidades
4. Verificar console por erros
5. Testar em diferentes navegadores

## 📝 Notas

- Alguns innerHTML podem ser mantidos se o conteúdo for 100% controlado
- Validação deve ser adicionada em todos os pontos de entrada
- Performance pode ser adicionada gradualmente

## 🆘 Problemas Comuns

### Erro: "Cannot find module"
**Solução**: Verificar caminhos de import. Usar caminhos relativos corretos.

### Erro: "createSafeElement is not a function"
**Solução**: Verificar se o módulo foi exportado corretamente.

### Performance piorou
**Solução**: Verificar se cache está sendo usado corretamente. Adicionar mais cache se necessário.

---

**Última atualização**: 2025-01-27

