/**
 * Utilitários de Performance
 * Otimizações para melhorar desempenho
 */

/**
 * Cache simples em memória
 */
export class SimpleCache {
    constructor(maxSize = 50, ttl = 300000) {
        this.cache = new Map();
        this.maxSize = maxSize;
        this.ttl = ttl; // Time to live em milissegundos
    }

    /**
     * Obtém item do cache
     * @param {string} key - Chave do item
     * @returns {any|null} - Item ou null se não encontrado/expirado
     */
    get(key) {
        const item = this.cache.get(key);
        if (!item) return null;

        // Verificar se expirou
        if (Date.now() - item.timestamp > this.ttl) {
            this.cache.delete(key);
            return null;
        }

        return item.value;
    }

    /**
     * Adiciona item ao cache
     * @param {string} key - Chave do item
     * @param {any} value - Valor a ser armazenado
     */
    set(key, value) {
        // Remover item mais antigo se cache está cheio
        if (this.cache.size >= this.maxSize) {
            const firstKey = this.cache.keys().next().value;
            this.cache.delete(firstKey);
        }

        this.cache.set(key, {
            value,
            timestamp: Date.now()
        });
    }

    /**
     * Limpa o cache
     */
    clear() {
        this.cache.clear();
    }

    /**
     * Remove itens expirados
     */
    cleanup() {
        const now = Date.now();
        for (const [key, item] of this.cache.entries()) {
            if (now - item.timestamp > this.ttl) {
                this.cache.delete(key);
            }
        }
    }
}

/**
 * Debounce - executa função após delay, cancelando execuções anteriores
 * @param {Function} func - Função a ser executada
 * @param {number} delay - Delay em milissegundos
 * @returns {Function} - Função com debounce
 */
export function debounce(func, delay = 300) {
    let timeoutId;
    return function (...args) {
        clearTimeout(timeoutId);
        timeoutId = setTimeout(() => func.apply(this, args), delay);
    };
}

/**
 * Throttle - limita execução de função a uma vez por período
 * @param {Function} func - Função a ser executada
 * @param {number} limit - Limite em milissegundos
 * @returns {Function} - Função com throttle
 */
export function throttle(func, limit = 300) {
    let inThrottle;
    return function (...args) {
        if (!inThrottle) {
            func.apply(this, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

/**
 * Fetch com cache
 * @param {string} url - URL a ser buscada
 * @param {object} options - Opções do fetch
 * @param {SimpleCache} cache - Instância do cache
 * @returns {Promise} - Promise com os dados
 */
export async function fetchWithCache(url, options = {}, cache) {
    // Verificar cache primeiro
    if (cache) {
        const cached = cache.get(url);
        if (cached !== null) {
            return cached;
        }
    }

    try {
        const response = await fetch(url, options);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const data = await response.json();

        // Armazenar no cache
        if (cache) {
            cache.set(url, data);
        }

        return data;
    } catch (error) {
        console.error('Erro ao buscar dados:', error);
        throw error;
    }
}

/**
 * Lazy loading de imagens
 * @param {HTMLImageElement} img - Elemento de imagem
 */
export function lazyLoadImage(img) {
    if (!img.dataset.src) return;

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                const image = entry.target;
                image.src = image.dataset.src;
                image.removeAttribute('data-src');
                observer.unobserve(image);
            }
        });
    }, {
        rootMargin: '50px'
    });

    observer.observe(img);
}

/**
 * Preload de recursos críticos
 * @param {Array<string>} urls - URLs dos recursos
 */
export function preloadResources(urls) {
    urls.forEach(url => {
        const link = document.createElement('link');
        link.rel = 'preload';
        link.href = url;
        link.as = url.endsWith('.css') ? 'style' : 'script';
        document.head.appendChild(link);
    });
}

/**
 * Mede performance de função
 * @param {Function} func - Função a ser medida
 * @param {string} label - Label para o log
 * @returns {any} - Resultado da função
 */
export function measurePerformance(func, label = 'Function') {
    const start = performance.now();
    const result = func();
    const end = performance.now();
    console.log(`${label} executado em ${(end - start).toFixed(2)}ms`);
    return result;
}

/**
 * Detecta conexão lenta
 * @returns {boolean} - True se conexão é lenta
 */
export function isSlowConnection() {
    if ('connection' in navigator) {
        const connection = navigator.connection;
        // Considerar lento se < 2G ou saveData ativado
        return connection.effectiveType === 'slow-2g' || 
               connection.effectiveType === '2g' ||
               connection.saveData === true;
    }
    return false;
}

/**
 * Otimiza imagens baseado na conexão
 * @param {string} imageUrl - URL da imagem
 * @returns {string} - URL otimizada
 */
export function optimizeImageForConnection(imageUrl) {
    if (isSlowConnection()) {
        // Adicionar parâmetros de compressão se suportado
        return imageUrl;
    }
    return imageUrl;
}

/**
 * Detecta se é um dispositivo móvel
 * @returns {boolean} - True se for mobile
 */
export function isMobileDevice() {
    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) ||
           (window.innerWidth <= 768 && window.innerHeight <= 1024);
}

/**
 * Otimiza performance para dispositivos móveis
 */
export function optimizeForMobile() {
    if (!isMobileDevice()) return;

    // Desabilitar animações pesadas em mobile
    document.documentElement.style.setProperty('--animation-duration', '0.01ms');

    // Otimizar scroll
    document.body.style.webkitOverflowScrolling = 'touch';
    document.body.style.overscrollBehavior = 'contain';

    // Reduzir complexidade visual
    const cards = document.querySelectorAll('.course-card');
    cards.forEach(card => {
        card.style.boxShadow = 'none';
        card.style.border = '1px solid var(--cor-borda)';
        card.style.animation = 'none';
    });

    // Otimizar imagens
    const images = document.querySelectorAll('img[data-src]');
    images.forEach(img => {
        if (isSlowConnection()) {
            img.style.display = 'none';
        } else {
            lazyLoadImage(img);
        }
    });

    console.log('Otimização mobile aplicada');
}

/**
 * Implementa gestos de swipe para navegação
 * @param {HTMLElement} element - Elemento para adicionar swipe
 * @param {Function} onSwipeLeft - Callback para swipe esquerda
 * @param {Function} onSwipeRight - Callback para swipe direita
 */
export function addSwipeGestures(element, onSwipeLeft, onSwipeRight) {
    if (!isMobileDevice()) return;

    let startX, startY, endX, endY;

    element.addEventListener('touchstart', (e) => {
        startX = e.touches[0].clientX;
        startY = e.touches[0].clientY;
    });

    element.addEventListener('touchend', (e) => {
        endX = e.changedTouches[0].clientX;
        endY = e.changedTouches[0].clientY;

        const diffX = startX - endX;
        const diffY = startY - endY;

        // Verificar se é um swipe horizontal (não vertical)
        if (Math.abs(diffX) > Math.abs(diffY) && Math.abs(diffX) > 50) {
            if (diffX > 0 && onSwipeLeft) {
                onSwipeLeft();
            } else if (diffX < 0 && onSwipeRight) {
                onSwipeRight();
            }
        }
    });
}

/**
 * Implementa pull-to-refresh
 * @param {HTMLElement} element - Elemento para pull-to-refresh
 * @param {Function} onRefresh - Callback quando refresh é acionado
 */
export function addPullToRefresh(element, onRefresh) {
    if (!isMobileDevice()) return;

    let startY = 0;
    let isPulling = false;
    const threshold = 80;

    element.addEventListener('touchstart', (e) => {
        startY = e.touches[0].clientY;
    });

    element.addEventListener('touchmove', (e) => {
        if (element.scrollTop === 0) {
            const currentY = e.touches[0].clientY;
            const diff = currentY - startY;

            if (diff > threshold) {
                isPulling = true;
                element.style.transform = `translateY(${Math.min(diff - threshold, 60)}px)`;
                e.preventDefault();
            }
        }
    });

    element.addEventListener('touchend', () => {
        if (isPulling) {
            element.style.transform = '';
            element.style.transition = 'transform 0.3s ease';
            setTimeout(() => {
                element.style.transition = '';
                if (onRefresh) onRefresh();
            }, 300);
        }
        isPulling = false;
    });
}

/**
 * Otimiza carregamento de recursos para mobile
 */
export function optimizeMobileResources() {
    if (!isMobileDevice()) return;

    // Preload apenas recursos críticos
    const criticalResources = [
        './css/styles.css',
        './css/responsive.css',
        './js/veloacademy.js'
    ];

    preloadResources(criticalResources);

    // Lazy load recursos não críticos
    setTimeout(() => {
        const nonCriticalResources = [
            './js/theme-toggle.js',
            './js/auth.js'
        ];

        nonCriticalResources.forEach(resource => {
            const link = document.createElement('link');
            link.rel = 'preload';
            link.href = resource;
            link.as = 'script';
            document.head.appendChild(link);
        });
    }, 2000);
}

/**
 * Melhora feedback tátil
 */
export function enhanceTouchFeedback() {
    if (!isMobileDevice()) return;

    // Adicionar feedback tátil para botões importantes
    const buttons = document.querySelectorAll('.btn, .quiz-option, .course-card');
    buttons.forEach(button => {
        button.addEventListener('touchstart', () => {
            if (navigator.vibrate) {
                navigator.vibrate(10); // Vibração leve
            }
        });
    });

    // Melhorar estados active
    const style = document.createElement('style');
    style.textContent = `
        @media (hover: none) and (pointer: coarse) {
            .btn:active, .quiz-option:active, .course-card:active {
                transform: scale(0.98);
                transition: transform 0.1s ease;
            }
        }
    `;
    document.head.appendChild(style);
}

