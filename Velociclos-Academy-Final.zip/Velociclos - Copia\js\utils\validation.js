/**
 * Utilitários de Validação
 * Validação de entrada de dados
 */

/**
 * Classe principal de validação
 */
export class Validator {
    /**
     * Valida um objeto baseado em regras
     * @param {object} obj - Objeto a ser validado
     * @param {object} rules - Regras de validação
     * @returns {object} - Resultado da validação {valid: boolean, errors: array}
     */
    static validateObject(obj, rules) {
        const errors = [];
        const validated = {};

        for (const [key, rule] of Object.entries(rules)) {
            const value = obj[key];
            const result = this.validateField(value, rule);

            if (!result.valid) {
                errors.push({
                    field: key,
                    message: result.message,
                    value: value
                });
            } else {
                validated[key] = result.value;
            }
        }

        return {
            valid: errors.length === 0,
            errors,
            data: validated
        };
    }

    /**
     * Valida um campo individual
     * @param {any} value - Valor a ser validado
     * @param {object} rule - Regra de validação
     * @returns {object} - Resultado da validação
     */
    static validateField(value, rule) {
        // Verificar se é obrigatório
        if (rule.required && (value === undefined || value === null || value === '')) {
            return {
                valid: false,
                message: 'Campo obrigatório',
                value: value
            };
        }

        // Se não é obrigatório e está vazio, é válido
        if (!rule.required && (value === undefined || value === null || value === '')) {
            return {
                valid: true,
                value: value
            };
        }

        // Validar tipo
        if (rule.type) {
            const typeResult = this.validateType(value, rule.type);
            if (!typeResult.valid) {
                return typeResult;
            }
        }

        // Executar validação customizada
        if (rule.validate && typeof rule.validate === 'function') {
            try {
                const customResult = rule.validate(value);
                if (customResult !== true) {
                    return {
                        valid: false,
                        message: typeof customResult === 'string' ? customResult : 'Validação customizada falhou',
                        value: value
                    };
                }
            } catch (error) {
                return {
                    valid: false,
                    message: 'Erro na validação customizada',
                    value: value
                };
            }
        }

        return {
            valid: true,
            value: value
        };
    }

    /**
     * Valida tipo de dado
     * @param {any} value - Valor a ser validado
     * @param {string} type - Tipo esperado
     * @returns {object} - Resultado da validação
     */
    static validateType(value, type) {
        switch (type) {
            case 'string':
                return this.validateString(value);
            case 'number':
                return this.validateNumber(value);
            case 'boolean':
                return this.validateBoolean(value);
            case 'array':
                return this.validateArray(value);
            case 'object':
                return this.validateObjectType(value);
            default:
                return {
                    valid: false,
                    message: `Tipo '${type}' não suportado`,
                    value: value
                };
        }
    }

    /**
     * Valida string
     * @param {any} value - Valor a ser validado
     * @param {number} minLength - Comprimento mínimo (opcional)
     * @param {number} maxLength - Comprimento máximo (opcional)
     * @returns {object} - Resultado da validação
     */
    static validateString(value, minLength = 0, maxLength = 1000) {
        if (typeof value !== 'string') {
            return {
                valid: false,
                message: 'Deve ser uma string',
                value: value
            };
        }

        if (value.length < minLength) {
            return {
                valid: false,
                message: `Deve ter pelo menos ${minLength} caracteres`,
                value: value
            };
        }

        if (value.length > maxLength) {
            return {
                valid: false,
                message: `Deve ter no máximo ${maxLength} caracteres`,
                value: value
            };
        }

        return {
            valid: true,
            value: value.trim()
        };
    }

    /**
     * Valida número
     * @param {any} value - Valor a ser validado
     * @param {number} min - Valor mínimo (opcional)
     * @param {number} max - Valor máximo (opcional)
     * @returns {object} - Resultado da validação
     */
    static validateNumber(value, min = -Infinity, max = Infinity) {
        const num = Number(value);
        if (isNaN(num)) {
            return {
                valid: false,
                message: 'Deve ser um número válido',
                value: value
            };
        }

        if (num < min) {
            return {
                valid: false,
                message: `Deve ser maior ou igual a ${min}`,
                value: value
            };
        }

        if (num > max) {
            return {
                valid: false,
                message: `Deve ser menor ou igual a ${max}`,
                value: value
            };
        }

        return {
            valid: true,
            value: num
        };
    }

    /**
     * Valida boolean
     * @param {any} value - Valor a ser validado
     * @returns {object} - Resultado da validação
     */
    static validateBoolean(value) {
        if (typeof value === 'boolean') {
            return {
                valid: true,
                value: value
            };
        }

        // Aceitar strings 'true'/'false'
        if (typeof value === 'string') {
            const lower = value.toLowerCase();
            if (lower === 'true') {
                return {
                    valid: true,
                    value: true
                };
            }
            if (lower === 'false') {
                return {
                    valid: true,
                    value: false
                };
            }
        }

        return {
            valid: false,
            message: 'Deve ser um valor booleano',
            value: value
        };
    }

    /**
     * Valida array
     * @param {any} value - Valor a ser validado
     * @param {number} minLength - Comprimento mínimo (opcional)
     * @param {number} maxLength - Comprimento máximo (opcional)
     * @returns {object} - Resultado da validação
     */
    static validateArray(value, minLength = 0, maxLength = 1000) {
        if (!Array.isArray(value)) {
            return {
                valid: false,
                message: 'Deve ser um array',
                value: value
            };
        }

        if (value.length < minLength) {
            return {
                valid: false,
                message: `Deve ter pelo menos ${minLength} itens`,
                value: value
            };
        }

        if (value.length > maxLength) {
            return {
                valid: false,
                message: `Deve ter no máximo ${maxLength} itens`,
                value: value
            };
        }

        return {
            valid: true,
            value: value
        };
    }

    /**
     * Valida objeto
     * @param {any} value - Valor a ser validado
     * @returns {object} - Resultado da validação
     */
    static validateObjectType(value) {
        if (value === null || typeof value !== 'object' || Array.isArray(value)) {
            return {
                valid: false,
                message: 'Deve ser um objeto',
                value: value
            };
        }

        return {
            valid: true,
            value: value
        };
    }

    /**
     * Valida email
     * @param {string} email - Email a ser validado
     * @returns {boolean} - True se válido
     */
    static isValidEmail(email) {
        if (typeof email !== 'string') return false;
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email) && email.length <= 254;
    }

    /**
     * Valida URL
     * @param {string} url - URL a ser validada
     * @returns {boolean} - True se válida
     */
    static isValidURL(url) {
        if (typeof url !== 'string') return false;
        try {
            const parsed = new URL(url);
            return ['http:', 'https:'].includes(parsed.protocol);
        } catch {
            return false;
        }
    }

    /**
     * Valida ID de curso
     * @param {string} courseId - ID do curso
     * @returns {boolean} - True se válido
     */
    static isValidCourseId(courseId) {
        if (typeof courseId !== 'string') return false;
        // Permitir apenas letras, números, hífens e underscores
        const sanitized = courseId.replace(/[^a-zA-Z0-9_-]/g, '');
        return sanitized.length > 0 && sanitized.length <= 50 && sanitized === courseId;
    }
}