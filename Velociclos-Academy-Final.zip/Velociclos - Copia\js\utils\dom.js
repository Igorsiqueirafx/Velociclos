/**
 * Utilitários DOM
 * Funções auxiliares para manipulação segura do DOM
 */

import { createSafeElement, escapeHTML } from './security.js';

/**
 * Substitui innerHTML de forma segura
 * @param {HTMLElement} element - Elemento a ser atualizado
 * @param {string|HTMLElement|Array} content - Conteúdo a ser inserido
 */
export function safeSetHTML(element, content) {
    if (!element || !(element instanceof HTMLElement)) {
        console.error('Elemento inválido para safeSetHTML');
        return;
    }

    // Limpar conteúdo anterior
    element.textContent = '';

    if (typeof content === 'string') {
        // Para strings simples, usar textContent
        element.textContent = content;
    } else if (content instanceof HTMLElement) {
        element.appendChild(content);
    } else if (Array.isArray(content)) {
        content.forEach(item => {
            if (item instanceof HTMLElement) {
                element.appendChild(item);
            } else if (typeof item === 'string') {
                element.appendChild(document.createTextNode(item));
            }
        });
    }
}

/**
 * Cria estrutura HTML complexa de forma segura
 * @param {string} template - Template HTML (sem scripts)
 * @param {object} data - Dados para substituição
 * @returns {DocumentFragment} - Fragmento com elementos criados
 */
export function createSafeHTML(template, data = {}) {
    const fragment = document.createDocumentFragment();
    const div = document.createElement('div');
    
    // Escapar dados antes de inserir
    let safeTemplate = template;
    for (const [key, value] of Object.entries(data)) {
        const placeholder = new RegExp(`\\{\\{${key}\\}\\}`, 'g');
        safeTemplate = safeTemplate.replace(placeholder, escapeHTML(String(value)));
    }
    
    div.innerHTML = safeTemplate;
    
    // Mover todos os nós para o fragmento
    while (div.firstChild) {
        fragment.appendChild(div.firstChild);
    }
    
    return fragment;
}

/**
 * Adiciona event listener de forma segura
 * @param {HTMLElement|string} element - Elemento ou seletor
 * @param {string} event - Tipo de evento
 * @param {Function} handler - Handler do evento
 * @param {object} options - Opções do listener
 */
export function safeAddEventListener(element, event, handler, options = {}) {
    const el = typeof element === 'string' 
        ? document.querySelector(element) 
        : element;
    
    if (!el) {
        console.warn(`Elemento não encontrado para evento ${event}`);
        return;
    }

    if (typeof handler !== 'function') {
        console.error('Handler deve ser uma função');
        return;
    }

    el.addEventListener(event, handler, options);
}

/**
 * Remove todos os event listeners de um elemento
 * @param {HTMLElement} element - Elemento
 * @param {string} event - Tipo de evento (opcional)
 */
export function removeAllListeners(element, event = null) {
    if (!element) return;
    
    // Clonar elemento remove todos os listeners
    const newElement = element.cloneNode(true);
    element.parentNode?.replaceChild(newElement, element);
}

/**
 * Verifica se elemento está visível
 * @param {HTMLElement} element - Elemento
 * @returns {boolean} - True se visível
 */
export function isElementVisible(element) {
    if (!element) return false;
    
    const style = window.getComputedStyle(element);
    return style.display !== 'none' && 
           style.visibility !== 'hidden' && 
           style.opacity !== '0';
}

/**
 * Scroll suave para elemento
 * @param {HTMLElement|string} element - Elemento ou seletor
 * @param {object} options - Opções de scroll
 */
export function smoothScrollTo(element, options = {}) {
    const el = typeof element === 'string' 
        ? document.querySelector(element) 
        : element;
    
    if (!el) return;

    el.scrollIntoView({
        behavior: 'smooth',
        block: 'start',
        ...options
    });
}


