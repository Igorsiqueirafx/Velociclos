// Sistema principal da Velociclos Academy
import { SimpleCache } from './utils/performance.js';
import { Validator } from './utils/validation.js';
import { createSafeElement, sanitizeHTML } from './utils/security.js';

class VeloAcademy {
    constructor() {
        this.cache = new SimpleCache();
        this.currentView = 'dashboard';
        this.user = null;
        this.courses = [];
        this.filteredCourses = [];
        this.currentFilters = {
            search: '',
            category: 'all',
            level: 'all'
        };
        this.init();
    }

    init() {
        this.loadUserData();
        this.loadCourses();
        this.setupEventListeners();
    }

    loadUserData() {
        const userData = localStorage.getItem('Velociclos_user_session');
        if (userData) {
            try {
                this.user = JSON.parse(userData);
                this.showUserInfo();
            } catch (error) {
                console.error('Erro ao carregar dados do usuário:', error);
            }
        }
    }

    showUserInfo() {
        const userInfo = document.getElementById('user-info');
        const userName = document.getElementById('user-name');
        const userAvatar = document.getElementById('user-avatar');

        if (userInfo && this.user) {
            userInfo.style.display = 'flex';

            if (userName) {
                userName.textContent = this.user.name || 'Usuário';
            }

            if (userAvatar && this.user.picture) {
                userAvatar.src = this.user.picture;
                userAvatar.style.display = 'block';
            }
        }
    }

    async loadCourses() {
        try {
            // Tentar carregar do cache primeiro
            let courses = this.cache.get('courses');

            if (!courses) {
                // Carregar do arquivo JSON com timeout
                const controller = new AbortController();
                const timeoutId = setTimeout(() => controller.abort(), 5000); // 5s timeout

                const response = await fetch('./cursos.json', {
                    signal: controller.signal,
                    headers: {
                        'Cache-Control': 'no-cache'
                    }
                });

                clearTimeout(timeoutId);

                if (response.ok) {
                    courses = await response.json();
                    // Validar estrutura dos dados
                    if (this.validateCoursesData(courses)) {
                        this.cache.set('courses', courses);
                    } else {
                        throw new Error('Dados dos cursos inválidos');
                    }
                } else {
                    throw new Error(`HTTP ${response.status}: ${response.statusText}`);
                }
            }

            this.courses = courses;
            this.filteredCourses = [...courses];
            this.updateStats();
            this.renderCurrentView();
        } catch (error) {
            console.error('Erro ao carregar cursos:', error);
            this.handleLoadError(error);
        }
    }

    validateCoursesData(courses) {
        return Array.isArray(courses) &&
               courses.every(course =>
                   course.id && course.title && course.description &&
                   typeof course.modules === 'number' &&
                   typeof course.duration === 'string'
               );
    }

    handleLoadError(error) {
        this.courses = this.getDefaultCourses();
        this.filteredCourses = [...this.courses];

        // Mostrar notificação de erro para o usuário
        this.showNotification('Erro ao carregar cursos. Usando dados locais.', 'error');

        this.updateStats();
        this.renderCurrentView();
    }

    showNotification(message, type = 'info') {
        // Implementar sistema de notificações se não existir
        console.warn(message);
        // Poderia integrar com toast existente se houver
    }

    getDefaultCourses() {
        return [
            {
                id: 'forex-iniciante',
                title: 'Forex para Iniciantes',
                description: 'Aprenda os fundamentos do mercado Forex',
                modules: 6,
                duration: '4 horas',
                level: 'Iniciante'
            },
            {
                id: 'analise-tecnica',
                title: 'Análise Técnica',
                description: 'Domine gráficos e indicadores técnicos',
                modules: 8,
                duration: '6 horas',
                level: 'Intermediário'
            }
        ];
    }

    setupEventListeners() {
        // Logout
        const logoutBtn = document.getElementById('logout-btn');
        if (logoutBtn) {
            logoutBtn.addEventListener('click', () => this.logout());
        }

        // Navegação
        document.addEventListener('click', (e) => {
            if (e.target.matches('.course-card-modern') || e.target.closest('.course-card-modern')) {
                const courseCard = e.target.closest('.course-card-modern');
                const courseId = courseCard?.dataset.courseId;
                if (courseId) {
                    this.openCourseModal(courseId);
                }
            }

            // Cards recomendados
            if (e.target.matches('.recommended-card') || e.target.closest('.recommended-card')) {
                const recommendedCard = e.target.closest('.recommended-card');
                const courseId = recommendedCard?.dataset.course;
                if (courseId) {
                    this.openCourse(courseId);
                }
            }

            // Fechar modal
            if (e.target.matches('.course-modal-close') || e.target.closest('.course-modal-close')) {
                this.closeCourseModal();
            }

            // Fechar modal clicando no overlay
                if (e.target.matches('.course-modal')) {
                    this.closeCourseModal();
                }
        });

        // Filtros e busca
        this.setupFilters();
    }

    setupFilters() {
        // Busca com debouncing e sugestões
        const searchInput = document.getElementById('course-search');
        const searchSuggestions = document.getElementById('search-suggestions');
        let debounceTimer;

        if (searchInput) {
            searchInput.addEventListener('input', (e) => {
                clearTimeout(debounceTimer);
                const query = e.target.value.toLowerCase().trim();

                // Atualizar filtros imediatamente para busca vazia
                if (query === '') {
                    this.currentFilters.search = '';
                    this.applyFilters();
                    this.hideSuggestions();
                    return;
                }

                // Mostrar sugestões se houver query
                this.showSuggestions(query);

                // Debounce para aplicar filtros
                debounceTimer = setTimeout(() => {
                    this.currentFilters.search = query;
                    this.applyFilters();
                    this.hideSuggestions();
                }, 300);
            });

            // Esconder sugestões ao clicar fora
            document.addEventListener('click', (e) => {
                if (!searchInput.contains(e.target) && !searchSuggestions.contains(e.target)) {
                    this.hideSuggestions();
                }
            });
        }

        // Filtros por categoria
        const categoryButtons = document.querySelectorAll('.category-btn');
        categoryButtons.forEach(btn => {
            btn.addEventListener('click', () => {
                // Remove active de todos
                categoryButtons.forEach(b => b.classList.remove('active'));
                // Adiciona active no clicado
                btn.classList.add('active');
                this.currentFilters.category = btn.dataset.filter;
                this.applyFilters();
            });
        });

        // Filtro por ordenação
        const sortFilter = document.getElementById('sort-filter');
        if (sortFilter) {
            sortFilter.addEventListener('change', (e) => {
                this.currentFilters.sort = e.target.value;
                this.applyFilters();
            });
        }

        // Botão voltar
        const backBtn = document.getElementById('back-to-courses');
        if (backBtn) {
            backBtn.addEventListener('click', () => {
                this.currentView = 'dashboard';
                this.renderCurrentView();
            });
        }

        // Botão voltar do quiz
        const backFromQuizBtn = document.getElementById('back-from-quiz');
        if (backFromQuizBtn) {
            backFromQuizBtn.addEventListener('click', () => {
                this.currentView = 'course';
                this.renderCurrentView();
            });
        }

        // Keyboard navigation
        document.addEventListener('keydown', (e) => {
            // ESC to close modal
            if (e.key === 'Escape') {
                this.closeCourseModal();
            }

            // Enter/Space on course cards
            if (e.target.matches('.course-card-modern') && (e.key === 'Enter' || e.key === ' ')) {
                e.preventDefault();
                const courseId = e.target.dataset.courseId;
                if (courseId) {
                    this.openCourseModal(courseId);
                }
            }
        });
    }

    showSuggestions(query) {
        const searchSuggestions = document.getElementById('search-suggestions');
        if (!searchSuggestions) return;

        const matches = this.courses.filter(course =>
            course.title.toLowerCase().includes(query) ||
            course.description.toLowerCase().includes(query)
        ).slice(0, 5); // Limitar a 5 sugestões

        if (matches.length === 0) {
            this.hideSuggestions();
            return;
        }

        searchSuggestions.innerHTML = '';
        matches.forEach(course => {
            const suggestionItem = document.createElement('div');
            suggestionItem.className = 'suggestion-item';
            suggestionItem.textContent = course.title;
            suggestionItem.addEventListener('click', () => {
                document.getElementById('course-search').value = course.title;
                this.currentFilters.search = course.title.toLowerCase();
                this.applyFilters();
                this.hideSuggestions();
            });
            searchSuggestions.appendChild(suggestionItem);
        });

        searchSuggestions.classList.add('show');
    }

    hideSuggestions() {
        const searchSuggestions = document.getElementById('search-suggestions');
        if (searchSuggestions) {
            searchSuggestions.classList.remove('show');
        }
    }

    renderCurrentView() {
        const views = document.querySelectorAll('.view');
        views.forEach(view => view.classList.remove('active'));

        const currentViewEl = document.getElementById(`${this.currentView}-view`);
        if (currentViewEl) {
            currentViewEl.classList.add('active');
        }

        if (this.currentView === 'dashboard') {
            this.renderCourses();
        }
    }

    renderCourses() {
        const coursesGrid = document.getElementById('courses-grid');
        const loadingEl = document.getElementById('courses-loading');
        const noCoursesEl = document.getElementById('no-courses');

        if (!coursesGrid) return;

        // Hide loading and no courses states
        if (loadingEl) loadingEl.style.display = 'none';
        if (noCoursesEl) noCoursesEl.style.display = 'none';

        coursesGrid.innerHTML = '';

        const coursesToRender = this.filteredCourses.length > 0 ? this.filteredCourses : this.courses;

        if (coursesToRender.length === 0) {
            coursesGrid.innerHTML = `
                <div class="no-courses">
                    <i class="fas fa-search"></i>
                    <h3>Nenhum curso encontrado</h3>
                    <p>Tente ajustar os filtros de busca</p>
                </div>
            `;
            return;
        }

        coursesToRender.forEach(course => {
            const courseCard = document.createElement('div');
            courseCard.className = 'course-card-modern';
            courseCard.dataset.courseId = course.id;
            courseCard.setAttribute('role', 'gridcell');
            courseCard.setAttribute('tabindex', '0');
            courseCard.setAttribute('aria-label', `Curso: ${course.title}`);
            courseCard.setAttribute('aria-describedby', `course-desc-${course.id}`);

            // Header do card
            const cardHeader = createSafeElement('div', { class: 'course-card-header' });
            const iconElement = createSafeElement('i', { class: 'fas fa-graduation-cap course-icon-large' });
            cardHeader.appendChild(iconElement);

            // Badge de nível
            const levelBadge = createSafeElement('div', { class: 'course-badge-modern' }, sanitizeHTML(course.level));

            // Conteúdo do card
            const cardContent = createSafeElement('div', { class: 'course-card-content' });

            // Título
            const title = createSafeElement('h3', {}, sanitizeHTML(course.title));
            cardContent.appendChild(title);

            // Descrição
            const description = createSafeElement('p', { id: `course-desc-${course.id}` }, sanitizeHTML(course.description));
            cardContent.appendChild(description);

            // Meta informações
            const cardMeta = createSafeElement('div', { class: 'course-card-meta' });

            // Rating (simulado)
            const rating = createSafeElement('div', { class: 'course-rating' });
            for (let i = 0; i < 5; i++) {
                const star = createSafeElement('i', { class: 'fas fa-star' });
                rating.appendChild(star);
            }
            cardMeta.appendChild(rating);

            // Preço
            const priceDiv = createSafeElement('div', { class: 'course-price-modern' });
            if (course.price) {
                priceDiv.textContent = `R$ ${course.price.toLocaleString('pt-BR')}`;
            } else {
                priceDiv.textContent = 'Consulte';
            }
            cardMeta.appendChild(priceDiv);

            cardContent.appendChild(cardMeta);

            // Montar card
            cardHeader.appendChild(levelBadge);
            courseCard.appendChild(cardHeader);
            courseCard.appendChild(cardContent);

            coursesGrid.appendChild(courseCard);
        });
    }

    applyFilters() {
        this.filteredCourses = this.courses.filter(course => {
            // Filtro de busca
            const matchesSearch = this.currentFilters.search === '' ||
                course.title.toLowerCase().includes(this.currentFilters.search) ||
                course.description.toLowerCase().includes(this.currentFilters.search);

            // Filtro de categoria
            const matchesCategory = this.currentFilters.category === 'all' ||
                course.category === this.currentFilters.category;

            // Filtro de nível
            const matchesLevel = this.currentFilters.level === 'all' ||
                course.level === this.currentFilters.level;

            return matchesSearch && matchesCategory && matchesLevel;
        });

        // Aplicar ordenação
        this.applySorting();

        requestAnimationFrame(() => this.renderCourses());
    }

    applySorting() {
        const sortBy = this.currentFilters.sort || 'popular';

        this.filteredCourses.sort((a, b) => {
            switch (sortBy) {
                case 'recent':
                    // Simular data mais recente (cursos com mais módulos primeiro)
                    return b.modules - a.modules;
                case 'price-low':
                    return (a.price || 0) - (b.price || 0);
                case 'price-high':
                    return (b.price || 0) - (a.price || 0);
                case 'rating':
                    // Simular rating (cursos mais caros têm melhor rating)
                    return (b.price || 0) - (a.price || 0);
                case 'popular':
                default:
                    // Popular: mais módulos primeiro
                    return b.modules - a.modules;
            }
        });
    }

    updateStats() {
        const totalCoursesEl = document.getElementById('total-courses');
        const totalHoursEl = document.getElementById('total-hours');
        const totalModulesEl = document.getElementById('total-modules');
        const completionRateEl = document.getElementById('completion-rate');

        if (totalCoursesEl) {
            totalCoursesEl.textContent = this.courses.length;
        }

        if (totalHoursEl) {
            const totalHours = this.courses.reduce((sum, course) => {
                const hours = parseInt(course.duration.split(' ')[0]) || 0;
                return sum + hours;
            }, 0);
            totalHoursEl.textContent = totalHours;
        }

        if (totalModulesEl) {
            const totalModules = this.courses.reduce((sum, course) => sum + (course.modules || 0), 0);
            totalModulesEl.textContent = totalModules;
        }

        if (completionRateEl) {
            // Simulação de taxa de conclusão (em produção viria do backend)
            completionRateEl.textContent = '87%';
        }
    }

    openCourse(courseId) {
        const course = this.courses.find(c => c.id === courseId);
        if (!course) return;

        // Verificar se existe página estática para o curso
        if (courseId === 'forex-iniciante') {
            // Redirecionar para a primeira aula do curso estático
            window.location.href = `./cursos-estáticos/forex-iniciante/f1-1.html`;
            return;
        }

        // Para outros cursos, usar a visualização dinâmica
        this.currentView = 'course';
        this.currentCourse = course;
        this.renderCurrentView();
    }

    getCourseSyllabus(courseId) {
        const syllabi = {
            'forex-iniciante': [
                'Conceitos básicos do mercado Forex',
                'Como funciona o trading de moedas',
                'Análise fundamental para iniciantes',
                'Primeiras operações práticas',
                'Gestão básica de risco'
            ],
            'analise-tecnica-basica': [
                'Introdução aos gráficos de preços',
                'Velas japonesas e padrões',
                'Indicadores técnicos essenciais',
                'Análise de tendências',
                'Identificação de pontos de entrada'
            ],
            'gestao-risco-avancada': [
                'Princípios da gestão de risco',
                'Cálculo de stop loss e take profit',
                'Diversificação de posições',
                'Controle emocional no trading',
                'Estratégias de proteção de capital'
            ],
            'estrategias-trading': [
                'Sistemas de entrada e saída',
                'Análise de múltiplos timeframes',
                'Combinação de análise técnica e fundamental',
                'Backtesting de estratégias',
                'Otimização de performance'
            ],
            'psicologia-trader': [
                'Controle emocional no trading',
                'Disciplina e consistência',
                'Gestão de expectativas',
                'Superando o medo e a ganância',
                'Mentalidade de trader profissional'
            ],
            'forex-completo': [
                'Todos os módulos dos cursos individuais',
                'Integração de conhecimentos',
                'Estratégias avançadas completas',
                'Simulações práticas intensivas',
                'Certificação completa'
            ],
            'expert-advisor-velociclos': [
                'Instalação e configuração do EA',
                'Parâmetros de otimização',
                'Monitoramento de performance',
                'Gestão de risco automatizada',
                'Suporte técnico especializado'
            ]
        };
        return syllabi[courseId] || ['Conteúdo específico do curso'];
    }

    openCourseModal(courseId) {
        const course = this.courses.find(c => c.id === courseId);
        if (!course) return;

        const modal = document.getElementById('course-modal');
        const modalBody = document.querySelector('.course-modal-body');

        if (!modal || !modalBody) return;

        // Criar conteúdo do modal
        const syllabus = this.getCourseSyllabus(course.id);
        modalBody.innerHTML = `
            <div class="course-modal-title">${sanitizeHTML(course.title)}</div>
            <div class="course-modal-meta">
                <span><i class="fas fa-clock"></i> ${sanitizeHTML(course.duration)}</span>
                <span><i class="fas fa-book"></i> ${course.modules} módulos</span>
                <span><i class="fas fa-signal"></i> ${sanitizeHTML(course.level)}</span>
                <span><i class="fas fa-users"></i> ${course.students || '100+'} alunos</span>
            </div>
            <div class="course-modal-description">
                ${sanitizeHTML(course.description)}
            </div>
            <div class="course-modal-syllabus">
                <h4>O que você aprenderá:</h4>
                <ul>
                    ${syllabus.map(item => `<li>${sanitizeHTML(item)}</li>`).join('')}
                </ul>
            </div>
            <div class="course-modal-features">
                <div class="course-modal-feature">
                    <i class="fas fa-check-circle"></i>
                    <span>Conteúdo 100% em português</span>
                </div>
                <div class="course-modal-feature">
                    <i class="fas fa-check-circle"></i>
                    <span>Certificado de conclusão</span>
                </div>
                <div class="course-modal-feature">
                    <i class="fas fa-check-circle"></i>
                    <span>Acesso vitalício</span>
                </div>
                <div class="course-modal-feature">
                    <i class="fas fa-check-circle"></i>
                    <span>Suporte da comunidade</span>
                </div>
                <div class="course-modal-feature">
                    <i class="fas fa-check-circle"></i>
                    <span>Material atualizado</span>
                </div>
            </div>
            <div class="course-modal-footer">
                <div class="course-modal-price">
                    ${course.price ? `R$ ${course.price.toLocaleString('pt-BR')}` : 'Consulte'}
                </div>
                <div class="course-modal-actions">
                    <button class="btn btn-secondary" onclick="window.veloAcademy.closeCourseModal()">
                        <i class="fas fa-times"></i>
                        Fechar
                    </button>
                    <button class="btn btn-primary" onclick="window.veloAcademy.openCourse('${course.id}')">
                        <i class="fas fa-play"></i>
                        Ver Curso
                    </button>
                </div>
            </div>
        `;

        // Mostrar modal
        modal.classList.add('show');
        document.body.style.overflow = 'hidden';
    }

    closeCourseModal() {
        const modal = document.getElementById('course-modal');
        if (modal) {
            modal.classList.remove('show');
            document.body.style.overflow = '';
        }
    }

    logout() {
        if (confirm('Tem certeza que deseja sair?')) {
            localStorage.removeItem('Velociclos_user_session');
            location.reload();
        }
    }

    scrollToTop() {
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    scrollToCourses() {
        const coursesSection = document.querySelector('.courses-section');
        if (coursesSection) {
            coursesSection.scrollIntoView({ behavior: 'smooth' });
        }
    }
}

// Inicializar quando DOM estiver pronto
document.addEventListener('DOMContentLoaded', () => {
    window.veloAcademy = new VeloAcademy();
});