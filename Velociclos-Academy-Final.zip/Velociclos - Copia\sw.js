// Service Worker básico para Velociclos
// Este é um service worker mínimo para evitar erros 404

const CACHE_NAME = 'velociclos-v1';
const urlsToCache = [
  '/',
  '/index.html',
  '/css/styles.css',
  '/css/responsive.css',
  '/js/theme-toggle.js',
  '/js/toast.js'
];

// Instalação do service worker
self.addEventListener('install', (event) => {
  console.log('Service Worker instalado');
  // Forçar ativação imediata
  self.skipWaiting();
});

// Ativação do service worker
self.addEventListener('activate', (event) => {
  console.log('Service Worker ativado');
  // Limpar caches antigos
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME) {
            console.log('Removendo cache antigo:', cacheName);
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
});

// Interceptar requisições (opcional - apenas para logging)
self.addEventListener('fetch', (event) => {
  // Apenas log das requisições, sem cache por enquanto
  console.log('SW: Interceptando requisição para:', event.request.url);
});