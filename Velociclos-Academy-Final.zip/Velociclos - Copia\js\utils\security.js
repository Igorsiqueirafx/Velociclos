/**
 * Utilitários de Segurança
 * Previne vulnerabilidades XSS, CSRF e outras ameaças
 */

/**
 * Sanitiza HTML removendo scripts e elementos perigosos
 * @param {string} html - HTML a ser sanitizado
 * @returns {string} - HTML sanitizado
 */
export function sanitizeHTML(html) {
    if (typeof html !== 'string') return '';
    
    const div = document.createElement('div');
    div.textContent = html;
    return div.innerHTML;
}

/**
 * Cria elementos DOM de forma segura
 * @param {string} tag - Tag do elemento
 * @param {object} attributes - Atributos do elemento
 * @param {string|Node|Array} content - Conteúdo do elemento
 * @returns {HTMLElement} - Elemento criado
 */
export function createSafeElement(tag, attributes = {}, content = '') {
    const element = document.createElement(tag);
    
    // Adicionar atributos de forma segura
    for (const [key, value] of Object.entries(attributes)) {
        if (key.startsWith('on')) {
            // Ignorar event handlers inline (vulneráveis)
            continue;
        }
        
        if (key === 'style' && typeof value === 'object') {
            Object.assign(element.style, value);
        } else if (key === 'class' && Array.isArray(value)) {
            element.classList.add(...value);
        } else {
            element.setAttribute(key, String(value));
        }
    }
    
    // Adicionar conteúdo de forma segura
    if (typeof content === 'string') {
        element.textContent = content;
    } else if (content instanceof Node) {
        element.appendChild(content);
    } else if (Array.isArray(content)) {
        content.forEach(item => {
            if (item instanceof Node) {
                element.appendChild(item);
            } else {
                element.appendChild(document.createTextNode(String(item)));
            }
        });
    }
    
    return element;
}

/**
 * Valida e sanitiza URL
 * @param {string} url - URL a ser validada
 * @returns {boolean} - True se a URL é segura
 */
export function validateURL(url) {
    if (typeof url !== 'string') return false;
    
    try {
        const parsed = new URL(url);
        // Permitir apenas http e https
        return ['http:', 'https:'].includes(parsed.protocol);
    } catch {
        return false;
    }
}

/**
 * Sanitiza dados do usuário antes de salvar
 * @param {object} userData - Dados do usuário
 * @returns {object} - Dados sanitizados
 */
export function sanitizeUserData(userData) {
    if (!userData || typeof userData !== 'object') return {};
    
    const sanitized = {};
    const allowedKeys = ['name', 'email', 'picture', 'timestamp'];
    
    for (const key of allowedKeys) {
        if (userData[key] !== undefined) {
            if (typeof userData[key] === 'string') {
                sanitized[key] = sanitizeHTML(userData[key]);
            } else {
                sanitized[key] = userData[key];
            }
        }
    }
    
    return sanitized;
}

/**
 * Valida email
 * @param {string} email - Email a ser validado
 * @returns {boolean} - True se o email é válido
 */
export function validateEmail(email) {
    if (typeof email !== 'string') return false;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email) && email.length <= 254;
}

/**
 * Gera token CSRF simples
 * @returns {string} - Token CSRF
 */
export function generateCSRFToken() {
    const array = new Uint8Array(16);
    crypto.getRandomValues(array);
    return Array.from(array, byte => byte.toString(16).padStart(2, '0')).join('');
}

/**
 * Valida token CSRF
 * @param {string} token - Token a ser validado
 * @param {string} storedToken - Token armazenado
 * @returns {boolean} - True se o token é válido
 */
export function validateCSRFToken(token, storedToken) {
    if (!token || !storedToken) return false;
    return token === storedToken && token.length === 32;
}

/**
 * Sanitiza string para uso em atributos HTML
 * @param {string} str - String a ser sanitizada
 * @returns {string} - String sanitizada
 */
export function escapeHTML(str) {
    if (typeof str !== 'string') return '';
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return str.replace(/[&<>"']/g, m => map[m]);
}

/**
 * Valida e sanitiza ID de curso
 * @param {string} courseId - ID do curso
 * @returns {string|null} - ID sanitizado ou null se inválido
 */
export function sanitizeCourseId(courseId) {
    if (typeof courseId !== 'string') return null;
    // Permitir apenas letras, números, hífens e underscores
    const sanitized = courseId.replace(/[^a-zA-Z0-9_-]/g, '');
    return sanitized.length > 0 && sanitized.length <= 50 ? sanitized : null;
}

