// sistema de Toggle de Tema - IMPLEMENTADO SEGUINDO GUIDELINE
// Velociclos - Sistema de Design

// Estado do tema
let isDarkMode = false;

// Função para alternar tema
const toggleDarkMode = () => {
    isDarkMode = !isDarkMode;
    
    if (isDarkMode) {
        document.documentElement.classList.add('dark');
        localStorage.setItem('Velociclos-theme', 'dark');
        updateThemeIcon(true);
    } else {
        document.documentElement.classList.remove('dark');
        localStorage.setItem('Velociclos-theme', 'light');
        updateThemeIcon(false);
    }
};

// Função para atualizar ícone do tema
const updateThemeIcon = (isDark) => {
    const themeWrapper = document.querySelector('.theme-switch-wrapper');
    if (themeWrapper) {
        const sunIcon = themeWrapper.querySelector('.bx-sun');
        const moonIcon = themeWrapper.querySelector('.bx-moon');

        if (sunIcon && moonIcon) {
            // Garantir estado limpo
            sunIcon.classList.remove('active');
            moonIcon.classList.remove('active');

            if (isDark) {
                // Mostrar lua
                moonIcon.classList.add('active');
            } else {
                // Mostrar sol
                sunIcon.classList.add('active');
            }
        }
    }
};

// Função para aplicar tema salvo ao carregar
const applySavedTheme = () => {
    const savedTheme = localStorage.getItem('Velociclos-theme') || 'light';
    const isDark = savedTheme === 'dark';

    if (isDark) {
        document.documentElement.classList.add('dark');
        isDarkMode = true;
    } else {
        document.documentElement.classList.remove('dark');
        isDarkMode = false;
    }
    updateThemeIcon(isDark);
};

// Função para detectar preferência do sistema
const detectSystemTheme = () => {
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
        return 'dark';
    }
    return 'light';
};

// Função para aplicar tema do sistema se não houver preferência salva
const applySystemTheme = () => {
    if (!localStorage.getItem('Velociclos-theme')) {
        const SystemTheme = detectSystemTheme();
        if (SystemTheme === 'dark') {
            document.documentElement.classList.add('dark');
            isDarkMode = true;
            updateThemeIcon(true);
        }
    }
};

// Função para detectar nível de zoom do navegador
const detectZoomLevel = () => {
    // Método mais confiável para detectar zoom
    const testElement = document.createElement('div');
    testElement.style.width = '100px';
    testElement.style.height = '100px';
    testElement.style.position = 'absolute';
    testElement.style.top = '-9999px';
    document.body.appendChild(testElement);

    const rect = testElement.getBoundingClientRect();
    document.body.removeChild(testElement);

    // Calcular zoom baseado na diferença entre CSS pixels e device pixels
    const zoom = Math.round((rect.width / 100) * 100) / 100;
    return zoom;
};

// Função para atualizar propriedades CSS baseadas no zoom
const updateZoomCSS = (zoomLevel) => {
    const root = document.documentElement;

    // Definir variável CSS para zoom
    root.style.setProperty('--zoom-factor', zoomLevel);

    // Aplicar classes baseadas no nível de zoom
    root.classList.remove('zoom-low', 'zoom-normal', 'zoom-high', 'zoom-extreme');

    if (zoomLevel < 0.8) {
        root.classList.add('zoom-low');
    } else if (zoomLevel <= 1.2) {
        root.classList.add('zoom-normal');
    } else if (zoomLevel <= 2.0) {
        root.classList.add('zoom-high');
    } else {
        root.classList.add('zoom-extreme');
    }
};

// Função para monitorar mudanças de zoom
const setupZoomMonitoring = () => {
    let lastZoom = detectZoomLevel();
    updateZoomCSS(lastZoom);

    // Verificar zoom periodicamente
    setInterval(() => {
        const currentZoom = detectZoomLevel();
        if (Math.abs(currentZoom - lastZoom) > 0.05) { // Threshold de 5%
            lastZoom = currentZoom;
            updateZoomCSS(currentZoom);
        }
    }, 500); // Verificar a cada 500ms

    // Também detectar mudanças de viewport/orientação
    window.addEventListener('resize', () => {
        setTimeout(() => {
            const newZoom = detectZoomLevel();
            updateZoomCSS(newZoom);
        }, 100);
    });
};

// Event Listeners
document.addEventListener('DOMContentLoaded', () => {
    // Aplicar tema salvo
    applySavedTheme();

    // Aplicar tema do sistema se não houver preferência
    applySystemTheme();

    // Configurar monitoramento de zoom
    setupZoomMonitoring();

    // Adicionar listener para o botão de tema
    const themeSwitch = document.querySelector('.theme-switch-wrapper');
    if (themeSwitch) {
        themeSwitch.addEventListener('click', toggleDarkMode);
    }

    // Listener para mudanças na preferência do sistema
    if (window.matchMedia) {
        window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', (e) => {
            if (!localStorage.getItem('Velociclos-theme')) {
                if (e.matches) {
                    document.documentElement.classList.add('dark');
                    isDarkMode = true;
                    updateThemeIcon(true);
                } else {
                    document.documentElement.classList.remove('dark');
                    isDarkMode = false;
                    updateThemeIcon(false);
                }
            }
        });
    }
});

// Exportar funções para uso externo
window.VelociclosTheme = {
    toggle: toggleDarkMode,
    isDark: () => isDarkMode,
    getCurrentTheme: () => isDarkMode ? 'dark' : 'light'
};
