// Dashboard administrativo (simulado)
import { createSafeElement } from './utils/security.js';

class AdminDashboard {
    constructor() {
        this.init();
    }

    init() {
        this.checkAdminAccess();
        this.loadDashboardData();
        this.setupAdminControls();
    }

    checkAdminAccess() {
        // Verificar se usuário é admin (simulado)
        const user = JSON.parse(localStorage.getItem('Velociclos_user_session') || 'null');
        if (!user || user.role !== 'admin') {
            alert('Acesso negado. Apenas administradores podem acessar esta página.');
            window.location.href = './index.html';
            return;
        }
    }

    loadDashboardData() {
        // Carregar dados simulados do dashboard
        const stats = {
            totalUsers: 1250,
            activeCourses: 8,
            totalRevenue: 45000,
            newRegistrations: 45
        };

        this.renderDashboard(stats);
    }

    renderDashboard(stats) {
        const statsContainer = document.getElementById('admin-stats');
        if (statsContainer) {
            // Limpar conteúdo anterior
            statsContainer.innerHTML = '';

            // Criar cards de forma segura
            const statCards = [
                { title: 'Total de Usuários', value: stats.totalUsers },
                { title: 'Cursos Ativos', value: stats.activeCourses },
                { title: 'Receita Total', value: `R$ ${stats.totalRevenue.toLocaleString()}` },
                { title: 'Novos Cadastros (mês)', value: stats.newRegistrations }
            ];

            statCards.forEach(stat => {
                const card = createSafeElement('div', { class: 'admin-stat-card' });
                const title = createSafeElement('h3', {}, stat.title);
                const value = createSafeElement('div', { class: 'stat-value' }, String(stat.value));

                card.appendChild(title);
                card.appendChild(value);
                statsContainer.appendChild(card);
            });
        }
    }

    setupAdminControls() {
        // Botões administrativos simulados
        const createCourseBtn = document.getElementById('create-course-btn');
        if (createCourseBtn) {
            createCourseBtn.addEventListener('click', () => {
                alert('Funcionalidade de criação de curso - Em desenvolvimento');
            });
        }

        const exportDataBtn = document.getElementById('export-data-btn');
        if (exportDataBtn) {
            exportDataBtn.addEventListener('click', () => {
                this.exportData();
            });
        }
    }

    exportData() {
        // Simulação de exportação
        const data = {
            users: [],
            courses: [],
            exportDate: new Date().toISOString()
        };

        const blob = new Blob([JSON.stringify(data, null, 2)], {
            type: 'application/json'
        });

        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `velociclos-admin-export-${new Date().toISOString().split('T')[0]}.json`;
        a.click();

        URL.revokeObjectURL(url);

        if (window.showToast) {
            window.showToast('Dados exportados com sucesso!', 'success');
        }
    }
}

// Inicializar dashboard admin
document.addEventListener('DOMContentLoaded', () => {
    new AdminDashboard();
});