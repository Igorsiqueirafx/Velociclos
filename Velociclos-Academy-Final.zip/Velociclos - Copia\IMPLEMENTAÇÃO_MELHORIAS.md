# Guia de Implementação de Melhorias

Este documento fornece exemplos práticos de como implementar as melhorias sugeridas na análise completa.

## 🚀 Início Rápido

### 1. Configuração Inicial

Crie um arquivo `.env` na raiz do projeto:

```env
# .env
VITE_GOOGLE_CLIENT_ID=seu-client-id-aqui
VITE_APPS_SCRIPT_URL=sua-url-aqui
VITE_API_BASE_URL=https://api.exemplo.com
```

### 2. Estrutura de Pastas Recomendada

```
js/
├── modules/
│   ├── auth/
│   │   ├── AuthService.js
│   │   └── AuthGuard.js
│   ├── courses/
│   │   ├── CourseService.js
│   │   └── CourseRenderer.js
│   └── quiz/
│       ├── QuizService.js
│       └── QuizRenderer.js
├── utils/
│   ├── security.js
│   ├── performance.js
│   ├── validation.js
│   └── dom.js
├── services/
│   ├── ApiService.js
│   └── StorageService.js
└── config/
    └── constants.js
```

## 🔒 Implementação de Segurança

### Exemplo 1: Substituir innerHTML

**ANTES (Vulnerável):**
```javascript
quizView.innerHTML = `<h2>Quiz - ${courseTitle}</h2>`;
```

**DEPOIS (Seguro):**
```javascript
import { createSafeElement } from './utils/security.js';

const title = createSafeElement('h2', {}, `Quiz - ${courseTitle}`);
quizView.appendChild(title);
```

### Exemplo 2: Validação de Entrada

```javascript
import { Validator } from './utils/validation.js';

function submitQuiz(answers) {
    const validation = Validator.validateObject(answers, {
        courseId: {
            type: 'string',
            required: true,
            validate: (v) => Validator.validateString(v, 1, 50)
        },
        answers: {
            type: 'array',
            required: true,
            validate: (v) => Validator.validateArray(v, 1, 100)
        }
    });
    
    if (!validation.valid) {
        console.error('Validação falhou:', validation.errors);
        return;
    }
    
    // Processar quiz...
}
```

### Exemplo 3: Sanitização de Dados do Usuário

```javascript
import { sanitizeUserData } from './utils/security.js';

function saveUser(userData) {
    const sanitized = sanitizeUserData(userData);
    localStorage.setItem('user', JSON.stringify(sanitized));
}
```

## ⚡ Implementação de Performance

### Exemplo 1: Cache de Requisições

```javascript
import { SimpleCache, fetchWithCache } from './utils/performance.js';

const apiCache = new SimpleCache(50, 300000); // 5 minutos

async function loadCourse(courseId) {
    const url = `/api/courses/${courseId}`;
    return await fetchWithCache(url, {}, apiCache);
}
```

### Exemplo 2: Debounce em Event Listeners

```javascript
import { debounce } from './utils/performance.js';

const searchInput = document.getElementById('search');
const debouncedSearch = debounce((query) => {
    performSearch(query);
}, 300);

searchInput.addEventListener('input', (e) => {
    debouncedSearch(e.target.value);
});
```

### Exemplo 3: Lazy Loading de Imagens

```javascript
import { lazyLoadImage } from './utils/performance.js';

document.querySelectorAll('img[data-src]').forEach(lazyLoadImage);
```

## 📱 Implementação de Responsividade

### Exemplo: Media Queries Melhoradas

```css
/* Mobile First */
.container {
    padding: 1rem;
}

/* Tablets */
@media (min-width: 768px) {
    .container {
        padding: 2rem;
        max-width: 750px;
    }
}

/* Laptops */
@media (min-width: 1024px) {
    .container {
        padding: 3rem;
        max-width: 1200px;
    }
}

/* Desktops */
@media (min-width: 1440px) {
    .container {
        max-width: 1400px;
    }
}

/* Large Screens */
@media (min-width: 2560px) {
    .container {
        max-width: 2400px;
    }
}
```

## 🧪 Implementação de Testes

### Exemplo: Teste Unitário

```javascript
// tests/utils/security.test.js
import { describe, test, expect } from 'vitest';
import { sanitizeHTML, validateURL } from '../../js/utils/security.js';

describe('Security Utils', () => {
    test('sanitizeHTML remove scripts', () => {
        const malicious = '<script>alert("XSS")</script>Hello';
        const sanitized = sanitizeHTML(malicious);
        expect(sanitized).not.toContain('<script>');
        expect(sanitized).toContain('Hello');
    });
    
    test('validateURL aceita apenas http/https', () => {
        expect(validateURL('https://example.com')).toBe(true);
        expect(validateURL('http://example.com')).toBe(true);
        expect(validateURL('javascript:alert(1)')).toBe(false);
    });
});
```

## 📝 Checklist de Migração

### Fase 1: Preparação
- [ ] Criar estrutura de pastas
- [ ] Configurar variáveis de ambiente
- [ ] Instalar dependências (se necessário)
- [ ] Criar arquivos utilitários

### Fase 2: Segurança
- [ ] Substituir todos os innerHTML
- [ ] Implementar validação de entrada
- [ ] Adicionar sanitização de dados
- [ ] Mover credenciais para .env

### Fase 3: Performance
- [ ] Implementar cache
- [ ] Adicionar debounce/throttle
- [ ] Implementar lazy loading
- [ ] Otimizar imagens

### Fase 4: Testes
- [ ] Escrever testes unitários
- [ ] Escrever testes de integração
- [ ] Configurar CI/CD
- [ ] Alcançar 80%+ coverage

## 🔗 Recursos Adicionais

- [Web.dev Security](https://web.dev/secure/)
- [MDN Web Security](https://developer.mozilla.org/en-US/docs/Web/Security)
- [OWASP Cheat Sheets](https://cheatsheetseries.owasp.org/)


